import React from 'react';
import logo from './logo.svg';
import './App.css';


class Header extends React.Component{

  render() {
    return (
        <nav className="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <ul className="navbar-nav">
          <li className="nav-item active">
            <a className="nav-link" href="#">Home</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">About</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Contact Us</a>
          </li>
        </ul>
    
        <form className="form-inline ml-4" action="/action_page.php">
          <input className="form-control mr-sm-2" type="text" placeholder="Search" />
          <button className="btn btn-success" type="submit">Search</button>
        </form>
        
        <div className="ml-auto text-white">
          <a className="text-white" href="#">Logout</a>
        </div>
        
      </nav>
    );
  }
  
}

export default Header;
